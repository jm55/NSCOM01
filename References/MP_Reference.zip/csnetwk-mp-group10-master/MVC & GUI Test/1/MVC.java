/**
 * MVC Class
 * 
 * @author SALAMANTE, Stephen
 * @author TULABOT, Victor
 */

public class MVC {

	public static void main(String[] args) {
		Client client = new Client();
		// Backend model = new Backend();
		// Controller controller = new Controller(model, client);
	}
}
