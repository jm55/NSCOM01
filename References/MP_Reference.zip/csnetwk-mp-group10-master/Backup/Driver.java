/**
 * Driver Class
 * 
 * @author SALAMANTE, Stephen
 * @author TULABOT, Victor
 */

public class Driver {

	public static void main(String[] args) {

		Client client = new Client();
		// CustomerInterface model = new CustomerInterface();
		// ControllerTest control = new ControllerTest(model, guiview);
	}
}