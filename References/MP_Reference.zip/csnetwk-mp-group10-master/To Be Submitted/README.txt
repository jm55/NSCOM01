DE LA SALLE USAP
BY SALAMANTE & TULABOT (Group 11)

Instructions:

1. Open three Terminal/Command Prompt windows.
2. For all Terminal/Command Prompt windows, set the directory to this folder.
3. Type on any window "javac *.java".
4. On two windows, type "java Client". And on the third window, type "java Server".
5. Three GUI windows should appear: Two (2) Client GUI windows, and one (1) Server GUI window.
6. On the Client GUI window, enter the following: Any username on the name, "localhost" on IP Address, and "9000" on Port Number.
7. Once done filling up the details for the Client GUI window, click proceed.
7. A client could only send a message or file when another client is connected.
8. To save the chatlog, click the "Save Log" button on the Server GUI window.
9. There will also be a prompt to save the chatlog when exiting the Server GUI window.
