# sockets-file-transfer
Java application for file transfers via TCP using Java Sockets  
  
1. Uses TCP for downloading files from server.  
  
2. Client GUI buit using Java AWT and Java Swing.  
  
3. Uses Java Socket Programming.
  
4. Multithreading  
  
5. Working directory for server can be specified as the first command line argument and the port as the second (default 8888)  
  
6. Displays files and directories present in the server working directory and allows the client to select files and download them onto the client system.  
