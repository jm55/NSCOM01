/** This is our Company class
 * @author SALAMANTE, Stephen E.
 * @author CARANDANG, Pauline
*/

public class Company{
	private String companyName;
	
	public Company(){
		companyName = "Johnny Moves";
	}
}