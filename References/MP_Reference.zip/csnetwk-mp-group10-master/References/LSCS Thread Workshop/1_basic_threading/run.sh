javac *.java

java Driver