javac Client.java

java Client