javac *.java

java Server