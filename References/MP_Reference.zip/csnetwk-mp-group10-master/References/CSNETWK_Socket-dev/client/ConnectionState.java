
public enum ConnectionState {
    INITIALIZING,
    CONNECTING,
    CONNECTED,
    CLOSED
}