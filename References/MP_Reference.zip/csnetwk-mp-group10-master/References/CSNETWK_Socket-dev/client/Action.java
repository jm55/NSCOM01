
public class Action {
    public static final int ADD_USER = 0;
    public static final int REMOVE_USER = 1;
    public static final int SEND_MESSAGE = 2;
    public static final int SEND_IMAGE = 3;
    public static final int RECEIVE_MESSAGE = 4;
    public static final int RECEIVE_IMAGE = 5;
    public static final int LOGOUT = 6;
    public static final int SEND_USERNAME = 7;
}