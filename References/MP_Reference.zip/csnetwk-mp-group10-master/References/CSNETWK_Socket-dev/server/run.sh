javac *.java

java Server 5000