
public enum ConnectionState {
    CONNECTED,
    CLOSED
}