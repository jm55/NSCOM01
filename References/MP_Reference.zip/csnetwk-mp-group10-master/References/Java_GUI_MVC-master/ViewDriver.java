

public class ViewDriver {

    public static void main(String[] args) {
        // Once the view is initialized, it is shown to the 
        // screen immediately
        View v = new View();
    }

}