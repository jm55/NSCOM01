# This will run the 3 MVC Classes
javac Model.java View.java Controller.java Driver.java

java Driver