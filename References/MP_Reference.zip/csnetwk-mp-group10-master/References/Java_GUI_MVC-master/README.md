# Java_GUI_MVC
Basic MVC(Model-View-Controller) in Java using Java swing

Prereq: Basic Java Programming
___
To run on Windows just run the commands in the `run.bat` file on the
console on the same directory or you can double click the file instead
___
To run on Mac/Linux just run the commands in the `run.sh` file on the
console on the same directory or you can type on the console
```
<filepath to the folder>/Java_GUI_MVC$ .\run.sh
```