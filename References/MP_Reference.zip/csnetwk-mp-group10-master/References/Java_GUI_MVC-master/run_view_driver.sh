# only runs the view class
javac View.java ViewDriver.java

java ViewDriver