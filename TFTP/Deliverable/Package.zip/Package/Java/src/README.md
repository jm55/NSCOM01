# Source Code Directory
1. [data](https://github.com/jm55DLSU/NSCOM01/tree/main/TFTP/Java/src/data) - This contains the TFTP packet and file data related class files.
2. [gui](https://github.com/jm55DLSU/NSCOM01/tree/main/TFTP/Java/src/gui) - This contains the GUI related class file.
3. [mains](https://github.com/jm55DLSU/NSCOM01/tree/main/TFTP/Java/src/mains) - This contains the driver (both production and testing) and GUI controller related class files.
4. [network](https://github.com/jm55DLSU/NSCOM01/tree/main/TFTP/Java/src/network) - This contains network related class file.
5. [utils](https://github.com/jm55DLSU/NSCOM01/tree/main/TFTP/Java/src/utils) - This contains the utility class files used in other class files.
